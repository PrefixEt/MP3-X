﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

namespace MP3_X
{
    public interface IMainForm
    {

        int Volume { get; }
        int TimeChange { set; get; }
        int TimeDuration { set; get; }
        void TimerStart();
        void TimerStop();
        event EventHandler AudioOpenClick;
        event EventHandler PlayClick;
        event EventHandler PauseClick;
        event EventHandler StopClick;
        event EventHandler BackClick;
        event EventHandler NextClick;
        event EventHandler VolumeChanged;
        event EventHandler Tick;

    }


    public partial class MainForm : Form, IMainForm
    {

        public MainForm()
        {
            
            InitializeComponent();
            btnOpenFile.Click += BtnOpenFile_Click;
            btnPlay.Click += BtnPlay_Click;
            btnPause.Click += BtnPause_Click;
            btnStop.Click += BtnStop_Click;
            btnNext.Click += BtnNext_Click;
            btnBack.Click += BtnBack_Click;
            tbVolume.ValueChanged += TbVolume_ValueChanged;
            timeTimer.Tick += TimeTimer_Tick;
            
        }


      
        private void TimeTimer_Tick(object sender, EventArgs e)
        {            
            if (Tick != null) Tick(this, EventArgs.Empty);
        }

        private void TbVolume_ValueChanged(object sender, EventArgs e)
        {       
            if (VolumeChanged != null) VolumeChanged(this, EventArgs.Empty);    
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            if (BackClick != null) BackClick(this, EventArgs.Empty);
        }

        private void BtnNext_Click(object sender, EventArgs e)
        {
            if (NextClick != null) NextClick(this, EventArgs.Empty);
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            if (StopClick != null) StopClick(this, EventArgs.Empty);
        }

        private void BtnPause_Click(object sender, EventArgs e)
        {
            if (PauseClick != null) PauseClick(this, EventArgs.Empty);
        }

        private void BtnPlay_Click(object sender, EventArgs e)
        {
            if (PlayClick != null) PlayClick(this, EventArgs.Empty);
           
            
        }

        private void BtnOpenFile_Click(object sender, EventArgs e)
        {           
            if (AudioOpenClick != null) AudioOpenClick(this, EventArgs.Empty);
                 

        }

      



        #region IMainForm;
       public int Volume { get{return tbVolume.Value;} }
       public event EventHandler AudioOpenClick;
       public event EventHandler PlayClick;
       public event EventHandler PauseClick;
       public event EventHandler StopClick;
       public event EventHandler BackClick;
       public event EventHandler NextClick;
       public event EventHandler VolumeChanged;
       public event EventHandler Tick;

       public int TimeChange {
            set { tbTime.Value = value; }
            get { return tbTime.Value; }
        }

        public int TimeDuration { set { tbTime.Maximum = value; } get { return tbTime.Maximum; } }

        public void TimerStart()
        {
            timeTimer.Start();
        }
        public void TimerStop()
        {
            timeTimer.Stop();
        }

       #endregion
    }

}
