﻿using System;
using System.IO;
using Un4seen.Bass;
using WMPLib;



namespace MP3_X.O
{
    public interface IFileMod
    {
        void OpenFile(string filePath);
        void PlayFile();
        void PauseFile();
        void StopFile();
        void Volume(int volume);
        void Back();
        void Next();
        double FileTime { get; set; }
        int Duration { get; }
       
    }
    

    public class FileMod: IFileMod

    {
        
        int _stream;
        string _FilePath;
       static bool InitBassDll;
       
       static bool InitBass()
        {
            if(!InitBassDll)
             InitBassDll = Bass.BASS_Init(-1, 44100, BASSInit.BASS_DEVICE_DEFAULT, IntPtr.Zero);
            return InitBassDll;
        }
               

        public void OpenFile(string filePath)
        {
            
            if (filePath != null && InitBassDll)
            {
                _FilePath = filePath;
                _stream = Bass.BASS_StreamCreateFile(_FilePath, 0, 0, BASSFlag.BASS_DEFAULT);
            }
         }

       public void PlayFile() {
            
            if (InitBassDll)
            {
                Bass.BASS_ChannelPlay(_stream, false);
                     
            }
        }


       public void PauseFile()
        {
            Bass.BASS_ChannelPause(_stream);
        }

       public void StopFile()
        {
            if (_stream != 0)
            {
                Bass.BASS_ChannelStop(_stream);
             
            }
        }


       public void Volume(int volume = 100) {
            if(_stream!= 0)
            Bass.BASS_ChannelSetAttribute(_stream, BASSAttribute.BASS_ATTRIB_VOL, ((float)volume)/100);
        }

       public void Back()
        {
        }

       public void Next()
        {
        }
      
        public double FileTime {

            get {return 0; }
            set { double x = value; }
        }

    

        public int Duration { get
            { return (int)Bass.BASS_ChannelBytes2Seconds(_stream, Bass.BASS_ChannelGetLength(_stream));  }
                            }
    }
}
