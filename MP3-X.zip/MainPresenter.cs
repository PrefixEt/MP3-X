﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MP3_X.O;

namespace MP3_X
{
    class MainPresenter
    {
        private readonly IMainForm _form;
        private readonly IFileMod _module;
        string FilePath;
        
        public MainPresenter(IMainForm form, IFileMod module)
        {
            _form = form;
            _module = module;

            _form.AudioOpenClick += _form_AudioOpenClick;
            _form.PlayClick += _form_PlayClick;
            _form.PauseClick += _form_PauseClick;
            _form.StopClick += _form_StopClick;
            _form.BackClick += _form_BackClick;
            _form.VolumeChanged += _form_VolumeChanged;
            _form.Tick += _form_Tick;
              
        }

        private void _form_Tick(object sender, EventArgs e)
        {
                     
           
            _form.TimeChange = (int)_module.FileTime;
        }

        private void _form_VolumeChanged(object sender, EventArgs e)
        {
            _module.Volume(_form.Volume);
        }

        private void _form_BackClick(object sender, EventArgs e)
        {
            _module.Back();
        }

        private void _form_StopClick(object sender, EventArgs e)
        {
            _module.StopFile();
            _form.TimerStop();

        }

        private void _form_PauseClick(object sender, EventArgs e)
        {
            _module.PauseFile();
            _form.TimerStop();

        }

        private void _form_PlayClick(object sender, EventArgs e)
        {
            if (FilePath != null)
            {
                _module.PlayFile();
                _form.TimeDuration = _module.Duration;
                _form.TimerStart();
               
               
            }
            else  _form_AudioOpenClick(this, EventArgs.Empty);
            }


        private void _form_AudioOpenClick(object sender, EventArgs e)
        {

            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "MP3|*.mp3";
            if (open.ShowDialog() == DialogResult.OK)
            {
                FilePath = open.FileName;              
            }
           
            _module.OpenFile(FilePath);
            _module.PlayFile();
           
            _form.TimeChange = (int)_module.FileTime;
            _form.TimeDuration = _module.Duration;
            _form.TimerStart();          

        }

    
         
        
    }
}
